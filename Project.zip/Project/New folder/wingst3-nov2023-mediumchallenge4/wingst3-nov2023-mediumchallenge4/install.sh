#!/bin/sh
cd ~/Desktop/Project/wingst3-nov2023-mediumchallenge4
/opt/anaconda3/bin/python -m pip install .tests/CustSegClust-0.1-py3-none-any.whl
/opt/anaconda3/bin/python -m pip install cryptography==41.0.5
/opt/anaconda3/bin/python -m pip install ImageHash

# if pkg is not installed we try to install it again
pkgloc=/opt/anaconda3/lib/python3.11/site-packages/CustSegClust
if [ ! -d ${pkgloc} ]
then
    /opt/anaconda3/bin/python -m pip install .tests/CustSegClust-0.1-py3-none-any.whl
fi

# remove the package and score generator files

rm -f .tests/test_wings.py
rm -f .tests/hidden_test.py

# if install2 file exists, then execute it

if [ -e install2.sh ];then
    sh install2.sh
fi

# remove the install2.sh
rm install2.sh

