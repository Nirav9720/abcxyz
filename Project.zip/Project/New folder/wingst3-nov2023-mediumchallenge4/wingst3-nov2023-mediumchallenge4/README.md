# Wings T3- Credit Card Customer Segmentation

🚀 **Welcome to the Wings November Digital Challenge: Unveiling Credit Card Customer Clusters! 🌐**
 
In this challenge, we beckon the data virtuosos, the code conjurers, and the algorithm architects to step into the arena of Credit Card Customer Segmentation. Your mission, should you choose to accept it, is to employ cutting-edge clustering techniques that transcend traditional boundaries. As you navigate the labyrinth of data, your algorithms will breathe life into clusters, transforming raw information into actionable insights.
 
The stakes are high, the data dynamic, and the challenge unprecedented. Unleash your analytical prowess, ignite the sparks of innovation, and craft a solution that not only segments customers but illuminates the path to a new era of personalized financial services.
 
Are you ready to redefine the future of credit intelligence? The journey begins now, and the accolades await the bold. Enter the Wings Digital Challenge, where data meets destiny, and the possibilities are as boundless as your imagination. Are you ready to unravel the patterns, unveil the secrets, and become the maestro of segmentation?

May the clusters align in your favor! 🌟

## <u> Data Set </u>

The Customer Credit Card Information Dataset can be used for Identifying Loyal Customers, Customer Segmentation, Targeted Marketing and other such use cases in the Marketing Industry.

A few tasks that can be performed using this dataset is as follows:

- Perform Data Cleaning, Preprocessing, Visualizing and Feature Engineering on the Dataset.
- Implement Heirarchical Clustering, K-Means Clustering models.
- Create RFM (Recency,Frequency,Monetary) Matrix to identify Loyal Customers.


Column | Description
:---|:---
`Customer Key` | Unique key for each customer
`Avg_Credit_Limit` | Average Credit Card Limit For The Customer
`Total_Credit_Cards` | Total Credit Cards Owned by the Customer
`Total_visits_bank` | Total Number of Bank Visits by the Customer
`Total_visits_online` | Total Visits Online by the Bank Customer
`Total_calls_made` | Total Calls Made by the Customer to the Bank

<hr>

------------------------------------------------------------------------------
**Coding**
- Open the wings_Question.ipynb file and follow the instructions to do the coding.
- Run each cell with the "SHIFT+ENTER" or run button in menu.
- Make sure to run the last cell in the notebook to check and save your answers
- **Note**: Please save your notebook with CTRL+S now and then to avoid loss.

------------------------------------------------------------------------------
**Testing the solution:**

- Run the last cell in the notebook to test your solution. The number of test cases passed will be shown for each question.

- **NOTE:** These test cases are only preliminary test cases. Hidden test cases will also be executed after the test submission to determine the score.

------------------------------------------------------------------------------
